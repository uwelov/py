from tkinter import *

height = 500
width = 500

root = Tk()
root.title('calculator')
root.geometry("%dx%d" % (height, width))
root.resizable(False, False)