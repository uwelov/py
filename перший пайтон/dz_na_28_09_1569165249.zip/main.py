a = int(input("Введите первое число\n\tОтвет:"))
b = int(input("Введите второе число\n\tОтвет:"))
for num in range(a,b):
    if(num%2==1):
        print(num,end=" ")



a = int(input("Введите первое число \n\tОтвет:"))
b = int(input("Введите второе число \n\tОтвет:"))
num = 1
for f in range(a,b):
    num = num * f
print("Произведение данного диапазон от",a,"до",b,"будет равно",num)



num = int(input("Введите число \n\tОтвет:"))
for x in range( 1, num + 1 ):
    for y in range( 1, x + 1 ):
        print( y, end = "" )
    print