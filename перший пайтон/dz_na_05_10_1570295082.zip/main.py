num=int(input("Введите число Ответ:"))
a=1
b=1
while a<=num:
    while b<=num:
        if(a*b==num):
            print(a,"*",b,"=",num)
        b+=1
    b=1
    a+=1