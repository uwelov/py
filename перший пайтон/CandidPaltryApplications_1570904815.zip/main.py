a = int(input("Введите килограммы\n\tОтвет:"))
def b (kg):
	result = kg/1000
	return result
Mlg = b(a)
print("В",a,"килограмм(е):",Mlg,"миллиграмм")