name=input("Введите своё имя\n\tОтвет:")
firstname=input("Введите свою фамилию\n\tОтвет:")
age=input("Введите свой возраст\n\t")
print("Привет,",name,firstname,",тебе",age,"лет")
